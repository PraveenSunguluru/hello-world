# -*- coding: utf-8 -*-
"""
Created on Fri Jul 15 15:10:41 2022

@author: sungkumar
"""

import pandas as pd
import numpy as np
import cv2
import os
from pdf2image import convert_from_path
from sklearn.cluster import MeanShift, estimate_bandwidth
from datetime import datetime,date,timedelta
import shutil

import warnings
warnings.filterwarnings('ignore')

MIN_MATCH_COUNT = 3
batchsize = 50


os.chdir("C:/Users/sungkumar/Desktop/ad_test/")

input_path = "Inbound/"
logos_path = "logos/"
output_path = "Outbound/"
pdf2img_path = "pdf2img/"
img_split_path = "img_splits/"
logos_gray_path  = "logos_gray/"
img_splits_gray_path = "img_splits_gray/"
results_path = "results/"
archieve_path = "archieve/"

final_df = pd.DataFrame()

def start_findNeedle(sourceImagePath, needleImagePath):
    startTime = datetime.now()
    image = cv2.imread(sourceImagePath)
    # cv2.imshow('Rainforest', image)
    # cv2.waitKey(0)
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    template = cv2.imread(needleImagePath, 0)

    result = cv2.matchTemplate(gray, template, cv2.TM_SQDIFF)
    min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(result)
    #print("min_val: ", min_val)
    #print("min_loc: ", min_loc)
    min_loc_dpi = [round(x/300,2) for x in min_loc]
    #print("min_loc_dpi: ", min_loc_dpi)

    height, width = template.shape[:2]

    top_left = max_loc
    bottom_right = (top_left[0] + width, top_left[1] + height)
    cv2.rectangle(image, top_left, bottom_right, (0, 0, 255), 5)
    endTime = datetime.now()
    totalTimeNeeded = endTime - startTime
    #print("totalTimeNeeded: ", totalTimeNeeded)

    return min_loc_dpi


def sift_detect(logos_gray_path,img_split_path,page_no,output_path,filename_src):    
    global final_df

    scanned_image_list = os.listdir(img_split_path)
    logo_image_list = os.listdir(logos_path)
    
    #print("scanned_image_list:::",scanned_image_list)
    
    for scan_img in scanned_image_list:
        for logo_img in logo_image_list:        
    
            scanned_image = scan_img
            logo_image = logo_img
            print("scanned_image:::", scanned_image)
            print("logo_image:::", logo_image)           
            #scanned_image = "split_15.png"
            
            img2 = cv2.imread(img_split_path +  scanned_image)
            img2_gray_scale = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)
            
            #img2_width, img2_height = img2.shape
            cv2.imwrite(img_splits_gray_path +  scanned_image, img2_gray_scale, [cv2.IMWRITE_PNG_COMPRESSION, 1])
           
            img1_org = cv2.imread(logos_gray_path + logo_image) 
            img1_gray_scale = cv2.cvtColor(img1_org, cv2.COLOR_BGR2GRAY)    
            
            sourceImagePath = filename_src
            needleImagePath = img_split_path +  scanned_image
            
            dpi_value = start_findNeedle(sourceImagePath, needleImagePath)
                            
            alg = cv2.xfeatures2d.SIFT_create()
        
            kp1, des1 = alg.detectAndCompute(img1_gray_scale, None)
            kp2, des2 = alg.detectAndCompute(img2_gray_scale, None)
            
            try:
                x = np.array([kp2[0].pt])           
                
                for i in range(len(kp2)):
                    x = np.append(x, [kp2[i].pt], axis=0)
                
                x = x[1:len(x)]
                
                bandwidth = estimate_bandwidth(x, quantile=0.1, n_samples=1000)
            
                if bandwidth == 0:
                    bandwidth = 0.1
                
                #finding clusters in search image using mean shift algorithm
                ms = MeanShift(bandwidth=bandwidth, bin_seeding=True, cluster_all=True)
                ms.fit(x)
                labels = ms.labels_
                cluster_centers = ms.cluster_centers_
                
                labels_unique = np.unique(labels)
                n_clusters_ = len(labels_unique)
                #print("number of estimated clusters : %d" % n_clusters_)
                
                s = [None] * n_clusters_
                for i in range(n_clusters_):
                    l = ms.labels_
                    d, = np.where(l == i)
                    s[i] = list(kp2[xx] for xx in d)
                
                des2_ = des2
                
                count_of_detect = []
                transformedcorners = []
                #for every cluster, apply FLANN feature matching
                for i in range(n_clusters_):
                    #i = 5
                    #print("cluster no :::",i)
                    kp2 = s[i]
                    l = ms.labels_
                    d, = np.where(l == i)
                    des2 = des2_[d, ]
                
                    if(len(kp2)<2 or len(kp1)<2):
                        continue
                
                    FLANN_INDEX_KDTREE = 0
                    index_params = dict(algorithm = FLANN_INDEX_KDTREE, trees = 5)
                    search_params = dict(checks = 50)
                
                    flann = cv2.FlannBasedMatcher(index_params, search_params)
                
                    des1 = np.float32(des1)
                    des2 = np.float32(des2)
                    
                    des1.shape
                    des2.shape
                    matches = flann.knnMatch(des1, des2, 2)
               
                    # store all the good matches as per Lowe's ratio test.
                    good = []
                    for m,n in matches: 
                        if m.distance < 0.29 * n.distance:
                            good.append(m)
                
                    if len(good)>3:
                        src_pts = np.float32([ kp1[m.queryIdx].pt for m in good ]).reshape(-1,1,2)
                        dst_pts = np.float32([ kp2[m.trainIdx].pt for m in good ]).reshape(-1,1,2)
                
                        M, mask = cv2.findHomography(src_pts, dst_pts, cv2.RANSAC, 2)
                        if M is None:
                            #print ("No Homography")
                            continue
                        else:
                            h, w = img1_gray_scale.shape
                            
                        corners = np.float32([ [0, 0], [0, h - 1], [w - 1, h - 1], [w - 1, 0] ]).reshape(-1, 1, 2)
                        transformedCorners = cv2.perspectiveTransform(corners, M)
                 
                        #print(transformedCorners)
                        x1=int(transformedCorners[0][0][0])
                        x2=int(transformedCorners[1][0][0])
                        x3=int(transformedCorners[2][0][0])
                        x4=int(transformedCorners[3][0][0])       
                        
                        x=int(transformedCorners[0][0][0])
                        y=int(transformedCorners[0][0][1])
        
                        if (x3-x1 < 3 or x4-x1 < 3):
                            transformedCorners = "P"
            
                        else:                
                        # Draw a polygon on the second image joining the Transformed_corners
                            img2 = cv2.rectangle(img2, (x,y), (x+w,y+h), (0,255,0), 3)
                            img2 = cv2.polylines(img2, [np.int32(transformedCorners)], True, (0, 255, 0), 3, cv2.LINE_AA)
                        
                        if len(transformedCorners) > 1:
                            count_of_detect.append(1)
                            transformedcorners.append(transformedCorners)
                        else:
                            count_of_detect.append(0)
                            transformedcorners.append(transformedCorners)
                        
                    else:
                        #print ("Not enough matches are found - %d/%d" % (len(good),MIN_MATCH_COUNT))
                        matchesMask = None
                        
                detections_found = sum(count_of_detect)
                print("<============ No of detections ===========>:::",detections_found)
            
            except:
                #print("found blank page")
                detections_found = 0
                
            if detections_found >= 1:
                cv2.imwrite(output_path + scanned_image + "_" + logo_image ,img2,[cv2.IMWRITE_PNG_COMPRESSION, 1])
            else:
                #print("<============= Detection not found for ===============>::",scanned_image)
                #continue
                pass
           
                    
            try:
                final_set = pd.DataFrame()
                final_set["scanned_image"]  = [scanned_image]
                final_set["original_logo"] = [logo_image]
                final_set["parent_logo"] = [logo_image.lstrip('inverted_')]            
                final_set["logos_Detected"] = [detections_found]
                final_set["Transformed_corners"] = [transformedcorners]
                final_set['logo_detected_flag'] = ['Yes' if x>=1 else 'No' for x in final_set["logos_Detected"]]
                final_set['page_no'] = [page_no]
                final_set['Img_size'] = [dpi_value]
                
               
                final_df = final_df.append(final_set, ignore_index = True)
                
            except:
                
                #print("please check the image of :::", scanned_image)
                final_set = pd.DataFrame()
                final_set["scanned_image"]  = [scanned_image]
                final_set["original_logo"] = [logo_image]
                final_set["parent_logo"] = [logo_image.lstrip('inverted_')]            
                final_set["logos_Detected"] = "Not detected properly... Please check"
                final_set["Transformed_corners"] = "None"
                final_set['logo_detected_flag'] = "None" 
                final_set['page_no'] = [page_no]
                final_set['Img_size'] = [dpi_value]
                
                final_df = final_df.append(final_set, ignore_index = True)     
                pass
    print("successfully completed the run for:::",filename_src.split("/")[1])
    
    return final_df

def extract_images(filename):
    image =cv2.imread(filename)
    gray = cv2.cvtColor(image,cv2.COLOR_BGR2GRAY)
    _, thresh = cv2.threshold(gray,150,255,cv2.THRESH_BINARY_INV)
    
    kernal = cv2.getStructuringElement(cv2.MORPH_CROSS,(9,9))
    dilated = cv2.dilate(thresh,kernal,iterations = 5)
    contours, hierarchy = cv2.findContours(dilated,cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
  
    ROI_number = 0 
    for contour in contours:
        [x,y,w,h] = cv2.boundingRect(contour)       
       
        if h > 10000 or w > 10000:
            continue
        if h < 200 or w < 200:
            continue
        
        cv2.rectangle(image,(x,y),(x+w,y+h),(255,0,255),2)
        ROI = image[y:y+h, x:x+h]
        cv2.imwrite(img_split_path + "split_{}.png".format(ROI_number), ROI)
        ROI_number += 1
    
    return

### convert the pdf to images #####
def main():
    for file in os.listdir(input_path):
        #file = "Sakshi_TS_13-07-2022.pdf"
        pages = convert_from_path(input_path + file)
        page_number = 1    
        for page in pages:
            page.save(pdf2img_path + file[:-4] + "_page_" + str(page_number) + ".png", 'PNG')
            print("successfully converted page No. _:::",page_number)
            page_number += 1
    
        ##### read the logos and convert them to gray scale #####
        for k in os.listdir(logos_path):
            original_logo = k
            img1_org = cv2.imread(logos_path + "/" + original_logo)    
            img1_gray_scale = cv2.cvtColor(img1_org, cv2.COLOR_BGR2GRAY)
            cv2.imwrite(logos_gray_path + original_logo,img1_gray_scale,[cv2.IMWRITE_PNG_COMPRESSION, 1])
            
            inverted_image = cv2.bitwise_not(img1_gray_scale)
            cv2.imwrite(logos_gray_path + "/inverted_" + original_logo ,inverted_image, [cv2.IMWRITE_PNG_COMPRESSION, 1])
            
        #### read each page to segment the images ####
        for img in os.listdir(pdf2img_path):
            filename_src = pdf2img_path + img
            page_no = "page_" + str(filename_src[:-4].split("_")[-1])
            
            split_images = extract_images(filename_src)
            logos_detect = sift_detect(logos_gray_path,img_split_path,page_no,output_path,filename_src)
        
            
            #### clear the data from the folder #####
            for files_del in os.listdir(img_split_path):
                os.remove(os.path.join(img_split_path,files_del))
            for files_del in os.listdir(img_splits_gray_path):
                os.remove(os.path.join(img_splits_gray_path,files_del))
                
            print("< =================== successfully completed scanning all pages =================== >")
        date_timestamp = datetime.now().strftime("%Y_%m_%d---%I_%M_%S_%p")   
        
        final_df_read = final_df[final_df['logo_detected_flag'] == "Yes"]
        drop_columns = ['scanned_image','original_logo','Transformed_corners']
        final_df_read.drop(drop_columns, axis=1, inplace=True)
        final_df_read = final_df_read.reset_index(drop= True)        
        
        ### write output to file ####
        final_df_read.to_csv(results_path + file[:-4] + "_" + date_timestamp + ".csv", index=False)   
    
    date_timestamp = datetime.now().strftime("%Y_%m_%d---%I_%M_%S_%p") 
    shutil.make_archive(archieve_path + "outbound" + "---" + date_timestamp, 'zip', output_path)
            
    #### clear the data from all folders  #####
    for files_del in os.listdir(pdf2img_path):
        os.remove(os.path.join(pdf2img_path,files_del))
    for files_del in os.listdir(logos_gray_path):
        os.remove(os.path.join(logos_gray_path,files_del))        
                
    print("completed all steps")

if __name__ == '__main__':
    main()